"use client"
import PortfolioClient from "../components/portfolio-client"

export default function PortfolioClientPage({ settings }) {
  return <PortfolioClient settings={settings} />
}
