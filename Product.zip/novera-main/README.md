Hi, thank you for purchasing this product from https://buzz.dev.

Get support: https://www.buzz.dev/tickets/new
Community Discord: https://discord.gg/buzz
Tailwind Docs: https://tailwindcss.com/